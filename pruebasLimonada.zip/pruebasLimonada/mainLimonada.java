package pruebasLimonada;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class mainLimonada {

  public static void main(String[] args) throws NumberFormatException, IOException {

    int ventaVasos, optLimonade, azucar;


    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    System.out.println("Bienveido a limonaditas");
    System.out.println("selecione una opcion a comprar");
    System.out.println("1. limonada sin azucar");
    System.out.println("2. limonada con azucar");
    optLimonade = Integer.parseInt(br.readLine());

    sinAzucar obj1 = new sinAzucar(); 
    conAzucar obj2 = new conAzucar();

    switch (optLimonade) {
      case 1:
         //limonada sin azucar
        System.out.println("cuantas limondas sin azucar desea pedir");
        ventaVasos = Integer.parseInt(br.readLine());
        obj1.setVentaVasos(ventaVasos);
        System.out.println("total dinero :"+obj1.calcularPrecio());
        System.out.println("consumio :"+obj1.totalVasosUtilizados() + "vasos");
        System.out.println("no Consumio azucar");
        break;
      case 2:
        //limonada con azucar
        System.out.println("cuantas limondas con azucar desea pedir");
        ventaVasos = Integer.parseInt(br.readLine());
        obj2.setVentaVasos(ventaVasos);
        System.out.println("cuantas cucharadas de azucar desea por cada limonada");
        azucar = Integer.parseInt(br.readLine());
        obj2.setAzucarUsada(azucar);
        System.out.println("total dinero :"+obj2.calcularPrecio());
        System.out.println("consumio :"+obj2.totalVasosUtilizados() + "vasos");
        System.out.println("total azucar consumida: " + obj2.totalAzucar());
        break;
      case 3:
        System.out.println("Total vendido");
      default:
        break;
    }

  }

}
