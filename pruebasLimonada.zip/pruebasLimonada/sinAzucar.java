package pruebasLimonada;

public class sinAzucar {

  private int vasos, ventaVasos;

  public sinAzucar() {
    vasos = 100;
  }

  public double calcularPrecio() {
    
    vasos = vasos-ventaVasos;
    return 0.45*ventaVasos;
    
  }
  
  public int totalVasosUtilizados() {
    
    return 100 - vasos;
    
  }
  
  public int getVentaVasos() {
    return ventaVasos;
  }


  public void setVentaVasos(int ventaVasos) {
    this.ventaVasos = ventaVasos;
  }
  
}



