package problema1;

public class conjuntoDatos {

	
		double n1,n2,result;
		String mensaje;
		
		public void asignar(double n1,double n2) {
			
			this.n1 = n1;
			this.n2 = n2;
			
			return;
			
		}
		
		public void Determinador() {
			
			if (n1%2 != 0) {
				mensaje = "es par";
				result = Math.pow(n2, 2);
			}
			
			if (n1%2 == 0) {
				mensaje = "valor absoluto";
				result = Math.abs(n2);
			}
		}
		
		public void imprimir() {
			
			System.out.println(mensaje+" "+result);
		}
		
}
