package problema1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class mainConjunto {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		String letra = "s";
		double n1,n2;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		conjuntoDatos obj = new conjuntoDatos();
		
		do {
			
			System.out.println("ingrese un numero");
			n1 = Integer.parseInt(br.readLine());
			System.out.println("ingrese otro numero");
			n2 = Integer.parseInt(br.readLine());
			obj.asignar(n1, n2);
			obj.Determinador();
			obj.imprimir();
			
			System.out.println("desea continuar (s) para si (n) para no");
			letra = br.readLine();
			
		} while (letra == "s");
		
		
	}

}
