package problema6;

public class Primeros500 {
	
	
	public void calcularPrimeros() {
		
		for (int i = 1; i <= 500; i+=4) {
			
			System.out.println(i);
			
		}
	}
	
	

}
