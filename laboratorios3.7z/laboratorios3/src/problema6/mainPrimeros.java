package problema6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class mainPrimeros {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
	
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Bienvednido al programa");
		Primeros500 obj = new Primeros500();
		obj.calcularPrimeros();
		
	}
}
