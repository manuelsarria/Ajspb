package problema4;

public class seisEnteros {
	
	int n1,n2,n3,n4,n5,n6;
	int mul3=0,par=0,mul7=0;
	double promedio;
	String mensaje;
	
	
	public void asignar(int n1,int n2,int n3,int n4,int n5,int n6) {
		
		this.n1 = n1;
		this.n2 = n2;
		this.n3 = n3;
		this.n4 = n4;
		this.n5 = n5;
		this.n6 = n6;
	}
	
	public void ValidarNumeros() {
		
	 int num [] = {n1,n2,n3,n4,n5,n6};
	 
	 for (int i = 0; i < num.length; i++) {
		
		 if (num[i]%3 == 0) {
			 
			 mul3 = mul3 +1;
			 
		 }
		 
		 if (num[i]%2 == 0) {
			 
			 par =par+1;
			 
		 }
		 
		 if (num[i]%7 == 0) {
			 
			 mul7 = mul7+num[i];
		 }		 
		 
	}
	 
	 promedio = ((par*100)/6);
	 
	 if (mul7 == 0) {
		 mensaje = "no ingreso ningun multiplo de 7";
	 } else if (mul7 > 0) {
		mensaje = "el resulatdo de la suma de los multiplos de 7 es: "+mul7;
	}
		
	}
	
	public void imprimir() {
		
		System.out.println("de los numeros ingresados: "+mul3+" son multiplos de 3");
		System.out.println(mensaje);
		System.out.println("el promedio de los numeros pares ingresados es de: "+promedio);
	}
}
