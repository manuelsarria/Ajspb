package problema4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class mainSeis {
	
		public static void main(String[] args) throws NumberFormatException, IOException {
			
			int n1,n2,n3,n4,n5,n6;
			
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println("ingrese un numero entero");
			n1 = Integer.parseInt(br.readLine());
			System.out.println("ingrese un numero entero");
			n2 = Integer.parseInt(br.readLine());
			System.out.println("ingrese un numero entero");
			n3 = Integer.parseInt(br.readLine());
			System.out.println("ingrese un numero entero");
			n4 = Integer.parseInt(br.readLine());
			System.out.println("ingrese un numero entero");
			n5 = Integer.parseInt(br.readLine());
			System.out.println("ingrese un numero entero");
			n6 = Integer.parseInt(br.readLine());
			
			seisEnteros obj = new seisEnteros();
			
			obj.asignar(n1, n2, n3, n4, n5, n6);
			obj.ValidarNumeros();
			obj.imprimir();
			
			
			
		}

}
