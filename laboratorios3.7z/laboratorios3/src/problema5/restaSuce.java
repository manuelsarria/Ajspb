package problema5;

public class restaSuce {
	
	double  num;
	String mensaje;
	
	public void asignar(double num) {
		
		this.num = num;
	}
	
	public void calcularPar() {
		
		
		do {
			
			num = num -2;
			
		} while (num >= 2);
		
		
		if(num == 0) {
			mensaje = "Es par";
		}
		
		if(num == 1) {
			mensaje = "Es impar";
		}
	}
	
	public void imprimir() {
		System.out.println(mensaje);
	}
	
	
	
}
