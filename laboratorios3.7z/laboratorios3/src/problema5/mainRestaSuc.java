package problema5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class mainRestaSuc {
	
public static void main(String[] args) throws NumberFormatException, IOException {
		
		
		double num;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("ingrese un numero");
		num = Integer.parseInt(br.readLine());
		restaSuce obj = new restaSuce();
		obj.asignar(num);
		obj.calcularPar();
		obj.imprimir();		
		
	}

}
