package problema9;

public class rangoNumeros {
	
	int a,b;
	
	public void generarNumeros() {
		
		for (int i = a; i <= b; i++) {
			
			System.out.println(i);
			
		}
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}
	
	
	
	

}
