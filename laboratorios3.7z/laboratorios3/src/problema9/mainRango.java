package problema9;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class mainRango {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		
		int a,b;
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("ingrese el numero inicial");
		a = Integer.parseInt(br.readLine());
		System.out.println("ingrese el numero final");
		b = Integer.parseInt(br.readLine());
		
		rangoNumeros obj = new rangoNumeros();
		obj.setA(a);
		obj.setB(b);
		obj.generarNumeros();
	}

}
