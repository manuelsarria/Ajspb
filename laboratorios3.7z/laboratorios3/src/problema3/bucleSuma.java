package problema3;

public class bucleSuma {
	
	double i = 2;
	double max = 100,acum = 0,resp,temp;
	
	public void calculoFor() {
		
		for (int i = 2; i  < 100; i+=3) {
			
			acum = acum + i;
			
		}
		
		resp = acum;
	}
	
	public void calculoWhile() {
		 
		i = 2;
		acum = 0;
		
		while (i < 100) {
			
			temp = i+=3;
			acum = acum + temp;
			
		}
		
		resp = acum;
	}
	
	
	public void calculoDoWhile() {
		
		i = 2;
		acum = 0;
		
		do {
			
			temp = i+=3;
			acum = acum + temp;
			
		} while (i < 100);
		
		resp = acum;
	}
	
	public void imprimir() {
		System.out.println(resp);
	}

}
