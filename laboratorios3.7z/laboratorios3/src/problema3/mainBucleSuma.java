package problema3;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class mainBucleSuma {
	
	public static void main(String[] args) {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("inician bucles .......");
		bucleSuma obj = new bucleSuma();
		obj.calculoFor();
		obj.imprimir();
		obj.calculoWhile();
		obj.imprimir();
		obj.calculoDoWhile();
		obj.imprimir();
		
	}

}
