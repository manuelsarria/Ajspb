package problema10;

public class imprimirTriangulo {
	
	int num;
	
	
	public void generarTriangulo() {
		
		/*
		
		for(int i=1 ;i<=num;i=i+1) {
            
			for(int j=0;j<i;j++) {
				
				
                System.out.print("*");
            }
			
            System.out.println();
        }
        */
		
		
		for(int i=num ;i > 0;i--) {
            
			for(int j=0;j<i;j++) {
				
				
                System.out.print("*");
            }
			
            System.out.println("");
        }
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}
	
	

}
