package problema10;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class mainPrint {
	
public static void main(String[] args) throws NumberFormatException, IOException {
		
		
		int num;
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("ingrese el numero");
		num = Integer.parseInt(br.readLine());
		
		imprimirTriangulo obj = new imprimirTriangulo();
		obj.setNum(num);
		obj.generarTriangulo();
		
	}

}
