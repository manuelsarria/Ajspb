package problema2;

public class primerValor {
	double x,n,result,acumulador;
	
	public void asignar(double x) {
		
		this.x = x;
		
	}
	
	public void primerVal() {
		
		n =0;
		
		acumulador = 0;
		
		do {
			
			n++;
			acumulador = acumulador +n;
			result = acumulador;
			
		} while (result <= x);
		
	}
	
	public void imprimir() {
		System.out.println("el primer valor de n que excede: "+x+" es: "+n);
	}
	
	
}
