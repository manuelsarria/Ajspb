package problema2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class mainPrimerValor {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		double x;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("ingrese un  numero");
		x =  Integer.parseInt(br.readLine());
		
		primerValor obj = new primerValor();
		obj.asignar(x);
		obj.primerVal();
		obj.imprimir();
		
	}

}
