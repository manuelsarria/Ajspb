package problema8;

public class mainNumerosPares {
	
	public static void main(String[] args) {
		
		numerosPares obj = new numerosPares();
		obj.calcularNumeros();
		obj.imprimir();
		
	}

}
