package problema8;

public class numerosPares {
	
	int par=0,impar=0;
	
	public void calcularNumeros() {
		
		for (int i = 0; i <= 200; i++) {
			
			if(i%2 == 0) {
				par = par + i;
			}else {
				impar = impar + i;
			}
			
		}
	}
	
	
	public void imprimir() {
		System.out.println("resultado de pares "+par);
		System.out.println("resultado de impares: "+impar);
	}

}
